import SwiftUI
import FirebaseAuth

struct SignUpView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var displayName: String = ""
    @State private var errorMessage: String = ""
    
    @EnvironmentObject private var model: Model
    @EnvironmentObject private var appState: AppState
    
    private var isFormValid: Bool {
        !email.isEmpty && !password.isEmpty && !displayName.isEmpty
    }
    
    private func signUp() async {
        do {
            let result = try await Auth.auth().createUser(withEmail: email, password: password)
            try await model.updateDisplayName(for: result.user, displayName: displayName)
            appState.routes.append(.main)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    var body: some View {
        ZStack {
            // Background
            LinearGradient(gradient: Gradient(colors: [Color.green.opacity(0.6), Color.blue.opacity(0.6)]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            // Sign Up Form
            VStack(spacing: 20) {
                Text("SIGN UP")
                    .font(.largeTitle)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                
                CustomTextField(placeholder: Text("Email").foregroundColor(.gray), text: $email)
                CustomSecureField(placeholder: Text("Password").foregroundColor(.gray), text: $password)
                CustomTextField(placeholder: Text("Display Name").foregroundColor(.gray), text: $displayName)
                
                HStack {
                    Spacer()
                    Button("Sign Up") {
                        Task {
                            await signUp()
                        }
                    }
                    .buttonStyle(FilledButtonStyle())
                    .disabled(!isFormValid)
                    
                    Button("Login") {
                        appState.routes.append(.login)
                    }
                    .buttonStyle(FilledButtonStyle())
                    
                    Spacer()
                }
                
                if !errorMessage.isEmpty {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .font(.caption)
                }
            }
            .padding()
        }
    }
}

// CustomTextField and FilledButtonStyle
// Use the same definitions as provided in the previous LoginView example

struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView()
            .environmentObject(Model())
            .environmentObject(AppState())
    }
}

