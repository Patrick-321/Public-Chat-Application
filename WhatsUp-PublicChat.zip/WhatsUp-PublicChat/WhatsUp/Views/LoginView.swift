import SwiftUI
import FirebaseAuth

struct LoginView: View {
    
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var errorMessage: String = ""
    @EnvironmentObject private var appState: AppState
    
    private var isFormValid: Bool {
        !email.isEmpty && !password.isEmpty
    }
    
    private func login() async {
        do {
            let _ = try await Auth.auth().signIn(withEmail: email, password: password)
            appState.routes.append(.main)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    var body: some View {
        ZStack {
            // Background color or gradient
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.6)]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            // Login Form
            VStack(spacing: 30) {
                Text("PUBLIC CHAT ROOM")
                    .font(.largeTitle)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                
                CustomTextField(placeholder: Text("Email").foregroundColor(.gray), text: $email)
                CustomSecureField(placeholder: Text("Password").foregroundColor(.gray), text: $password)
                
                HStack {
                    Spacer()
                    Button("Login") {
                        Task {
                            await login()
                        }
                    }
                    .buttonStyle(FilledButtonStyle())
                    .disabled(!isFormValid)

                    Button("SignUp") {
                        appState.routes.append(.signUp)
                    }
                    .buttonStyle(FilledButtonStyle())
                    Spacer()
                }
                if !errorMessage.isEmpty {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .font(.caption)
                }
            }
            .padding()
        }
    }
}

// Custom Text Field Style
struct CustomTextField: View {
    var placeholder: Text
    @Binding var text: String
    
    var body: some View {
        ZStack(alignment: .leading) {
            if text.isEmpty {
                placeholder
            }
            TextField("", text: $text)
                .textInputAutocapitalization(.never)
        }
        .padding()
        .background(Color.white.opacity(0.8))
        .cornerRadius(10)
        .padding(.horizontal, 20)
    }
}

// Custom Secure Field Style
struct CustomSecureField: View {
    var placeholder: Text
    @Binding var text: String
    
    var body: some View {
        ZStack(alignment: .leading) {
            if text.isEmpty {
                placeholder
            }
            SecureField("", text: $text)
                .textInputAutocapitalization(.never)
        }
        .padding()
        .background(Color.white.opacity(0.8))
        .cornerRadius(10)
        .padding(.horizontal, 20)
    }
}



struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
            .environmentObject(AppState())
    }
}

