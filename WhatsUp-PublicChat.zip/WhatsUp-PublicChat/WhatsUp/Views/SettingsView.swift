import SwiftUI
import FirebaseAuth
import FirebaseStorage

struct SettingsConfig {
    var showPhotoOptions: Bool = false
    var sourceType: UIImagePickerController.SourceType?
    var selectedImage: UIImage?
    var displayName: String = ""
}

struct SettingsView: View {
    @State private var settingsConfig = SettingsConfig()
    @FocusState var isEditing: Bool
    @EnvironmentObject private var model: Model
    @EnvironmentObject private var appState: AppState
    
    @State private var currentPhotoURL: URL? = Auth.auth().currentUser?.photoURL
    
    @State private var showSignOutAlert = false
    @State private var showSaveAlert = false
    @State private var navigateToLogin = false
    
    var displayName: String {
        guard let currentUser = Auth.auth().currentUser else { return "Guest" }
        return currentUser.displayName ?? "Guest"
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                // Background Gradient
                LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.4), Color.blue.opacity(0.4)]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)

                VStack(spacing: 20) {
                    Text("Edit Profile")
                        .font(.largeTitle)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                    // Profile Picture
                    AsyncImage(url: currentPhotoURL) { image in
                        image.resizable()
                            .scaledToFit()
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.white, lineWidth: 4))
                    } placeholder: {
                        Image(systemName: "person.crop.circle.fill")
                            .font(.system(size: 100))
                            .foregroundColor(.gray)
                    }
                    .frame(width: 100, height: 100)
                    .onTapGesture {
                        settingsConfig.showPhotoOptions = true
                    }
                    .confirmationDialog("Select", isPresented: $settingsConfig.showPhotoOptions) {
                        Button("Camera") {
                            settingsConfig.sourceType = .camera
                        }
                        Button("Photo Library") {
                            settingsConfig.sourceType = .photoLibrary
                        }
                    }

                    // Display Name Field
                    TextField("Display Name", text: $settingsConfig.displayName)
                        .textFieldStyle(.roundedBorder)
                        .focused($isEditing)
                        .padding()

                    // Sign Out Button
                    Button("Signout") {
                        showSignOutAlert = true
                    }
                    .buttonStyle(FilledButtonStyle())
                    .alert(isPresented: $showSignOutAlert) {
                        Alert(
                            title: Text("Sign Out"),
                            message: Text("Are you sure you want to sign out?"),
                            primaryButton: .destructive(Text("Sign Out")) {
                                signOut()
                            },
                            secondaryButton: .cancel()
                        )
                    }
//                    NavigationLink("", destination: LoginView(), isActive: $navigateToLogin)
                }
                .padding()
            }
            .sheet(item: $settingsConfig.sourceType, content: { sourceType in
                ImagePicker(image: $settingsConfig.selectedImage, sourceType: sourceType)
            })
            .onChange(of: settingsConfig.selectedImage, perform: { image in
                // Image processing and uploading logic
                // resize the image
                guard let img = image,
                      let resizedImage = img.resize(to: CGSize(width: 100, height: 100)),
                      let imageData = resizedImage.pngData()
                else { return }
                
                // upload the image to Firebase Storage to get the url
                Task {
                    guard let currentUser = Auth.auth().currentUser else { return }
                    let filename = "\(currentUser.uid).png"
                    
                    do {
                        let url = try await Storage.storage().uploadData(for: filename, data: imageData, bucket: .photos)
                        try await model.updatePhotoURL(for: currentUser, photoURL: url)
                        currentPhotoURL = url
                        
                    } catch {
                        print(error)
                    }
                }
            })
            .onAppear {
                settingsConfig.displayName = displayName
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        guard let currentUser = Auth.auth().currentUser else { return }
                        showSaveAlert = true
                        Task {
                            do {
                                try await model.updateDisplayName(for: currentUser, displayName: settingsConfig.displayName)
                            } catch {
                                print(error)
                            }
                        }
                    }
                    .alert(isPresented: $showSaveAlert) {
                        Alert(
                            title: Text("Saved successfully"),
                            message: Text("Profile is changed"),
                            dismissButton: .default(Text("OK")) {
      
                            }
                        )
                    }
                }
            }
        }
    }

    func signOut() {
        do {
            try Auth.auth().signOut()
            appState.routes.append(.signOut)
        } catch {
            print("Error occurred during sign out!")
        }
    }
}

// FilledButtonStyle definition
struct FilledButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .background(Color.blue.opacity(0.85))
            .foregroundColor(.white)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .scaleEffect(configuration.isPressed ? 0.95 : 1)
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
            .environmentObject(Model())
            .environmentObject(AppState())
    }
}

