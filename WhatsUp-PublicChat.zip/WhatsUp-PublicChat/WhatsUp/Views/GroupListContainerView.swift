import SwiftUI

struct GroupListContainerView: View {
    @State private var isPresented: Bool = false
    @EnvironmentObject private var model: Model

    var body: some View {
        ZStack {
            // Updated Gradient Background
            LinearGradient(gradient: Gradient(colors: [Color.pink.opacity(0.6), Color.blue.opacity(0.6), Color.purple.opacity(0.6)]), startPoint: .topLeading, endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)

            VStack {
                // Header
                Text("Your Groups")
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                    .foregroundColor(Color.white)
                    .padding(.top, 20)

                // New Group Button
                Button(action: {
                    isPresented = true
                }) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                            .foregroundColor(.yellow)
                        Text("New Group")
                            .fontWeight(.medium)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.white.opacity(0.2))
                    .cornerRadius(10)
                    .shadow(radius: 5)
                }
                .padding(.horizontal)
                .padding(.bottom, 20)

                // Group List
                GroupListView(groups: model.groups)
                    .padding(.horizontal)
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(10)
                    .shadow(radius: 5)

                Spacer()
            }
        }
        .navigationBarBackButtonHidden(true)
        .padding(.bottom)
        .sheet(isPresented: $isPresented) {
            AddNewGroupView()
        }
        .task {
            do {
                try await model.populateGroups()
            } catch {
                print(error)
            }
        }
    }
}

struct GroupListContainerView_Previews: PreviewProvider {
    static var previews: some View {
        GroupListContainerView()
            .environmentObject(Model())
    }
}

